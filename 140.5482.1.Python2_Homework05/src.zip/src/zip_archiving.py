import zipfile
import os
import glob
import shutil
os.chdir("V:\\workspace\\Python2_Homework05")

def arch(path="V:\\workspace\\Python2_Homework05\\src"):
    t = os.path.basename(path)
    tt = os.path.basename(path)+os.sep
    print(tt)
    archive_f = t+".zip"
    print(os.path.abspath(archive_f))
    print(os.path.dirname(path))
    print(os.getcwd())
    f = glob.glob(os.path.join(path,'*.*'))
    print(f)
    zf = zipfile.ZipFile(archive_f, "w")
    for el in f:
        if os.path.isfile(el):
            zf.write(os.path.join(tt,os.path.basename(el)))
            print(os.path.join(tt,os.path.basename(el)))
    zf.close()
    z = zipfile.ZipFile(archive_f, "r")
    print(z.namelist())
    z.close()

if __name__ == "__main__":
    arch()
    