import zipfile
import os
import glob
import shutil

path = ("v:\\workspace\\python2_Lesson05\\src\\atest")
#os.mkdir(path)
def arch():
    t = os.path.basename(path)
    archive_f = t+".zip"
    print(os.path.abspath(archive_f))
    f = glob.glob('*.*')
    zf = zipfile.ZipFile(archive_f, "w")
    for el in f:
        if os.path.isfile(el):
            zf.write(el)
    zf.close()
    z = zipfile.ZipFile(archive_f, "r")
    print(z.namelist())
    z.close()
    #os.rmdir()

if __name__ == "__main__":
    arch()
    #os.remove("v:\workspace\python2_Lesson05\src\ARCH.zip")